// D:\Projet\BeBit\bebit - new\client\src\pages\club\club-events-page.tsx
import React, { useState } from 'react';
import ResponsiveLayout from '../../layouts/ResponsiveLayout';
import { Calendar, Clock, MapPin, Users, DollarSign, Music, Bookmark, AlertCircle, Truck, Coffee, Award, Trash2, Plus, User, Ticket, CheckCircle, XCircle, Download, Eye } from 'lucide-react';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useLocation } from 'wouter';
import { Textarea } from '@/components/ui/textarea'; // Ajout pour textarea contrôlée
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

// Type définition pour un événement (promotion + artistes avec images)
interface Artist {
  name: string;
  image: string;
}

interface Ticket {
  id: number;
  user: { name: string; email: string; phone?: string };
  ticketType: string;
  price: number;
  purchaseDate: string;
  isUsed: boolean;
}

interface Event {
  id: number;
  title: string;
  date: string;
  status: 'upcoming' | 'planning' | 'past' | 'cancelled';
  reservations: number;
  capacity: number;
  sales: number;
  coverImage: string; // URL d'image
  description: string;
  location: string;
  time: string;
  artists: Artist[];
  ticketTypes: {
    name: string;
    price: number;
    available: number;
    sold: number;
  }[];
  tickets: Ticket[]; // Nouveau: liste des tickets individuels (fictifs pour maquette)
  promotion?: {
    title: string;
    description: string;
    start: string;
    end: string;
    discount: number;
    code?: string;
    channels: string[];
  };
}

// Données initiales étendues (10 événements, variété de statuts/dates pour filtres, images Unsplash pour démo)
// Ajout de tickets fictifs pour chaque événement (5-10 par événement pour maquette, basés sur 'sold')
const initialEvents: Event[] = [
  {
    id: 1,
    title: "Summer Night Party",
    date: "15 juillet 2025",
    status: "past",
    reservations: 145,
    capacity: 180,
    sales: 25200000,
    coverImage: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=160&fit=crop",
    description: "Une soirée d'été exceptionnelle avec les meilleurs DJ de la ville pour une expérience inoubliable sous les étoiles.",
    location: "Terrasse principale",
    time: "21:00 - 04:00",
    artists: [
      { name: "DJ Phoenix", image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=40&h=40&fit=crop&crop=face" },
      { name: "Lisa Groove", image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&crop=face" }
    ],
    ticketTypes: [
      { name: "Standard", price: 180000, available: 35, sold: 110 },
      { name: "VIP", price: 300000, available: 0, sold: 35 }
    ],
    tickets: [ // Fictifs: 5 exemples pour maquette (sur 145 vendus)
      { id: 1, user: { name: "Alice Dupont", email: "alice@example.com", phone: "+261 34 12 345 67" }, ticketType: "Standard", price: 180000, purchaseDate: "2025-07-10", isUsed: true },
      { id: 2, user: { name: "Bob Martin", email: "bob@example.com" }, ticketType: "VIP", price: 300000, purchaseDate: "2025-07-12", isUsed: true },
      { id: 3, user: { name: "Claire Lefèvre", email: "claire@example.com", phone: "+261 32 98 765 43" }, ticketType: "Standard", price: 180000, purchaseDate: "2025-07-14", isUsed: false },
      { id: 4, user: { name: "David Roux", email: "david@example.com" }, ticketType: "VIP", price: 300000, purchaseDate: "2025-07-15", isUsed: true },
      { id: 5, user: { name: "Eva Simon", email: "eva@example.com" }, ticketType: "Standard", price: 180000, purchaseDate: "2025-07-01", isUsed: true }
    ],
    promotion: undefined
  },
  {
    id: 2,
    title: "DJ Elektra Live",
    date: "22 août 2025",
    status: "past",
    reservations: 42,
    capacity: 200,
    sales: 8400000,
    coverImage: "https://images.unsplash.com/photo-1517457373958-b7bdd458720e?w=400&h=160&fit=crop",
    description: "DJ Elektra fait son retour avec un set électronique exceptionnel mêlant techno et house progressive.",
    location: "Salle principale",
    time: "22:00 - 05:00",
    artists: [
      { name: "DJ Elektra", image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop&crop=face" },
      { name: "Mark Vega", image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face" }
    ],
    ticketTypes: [
      { name: "Entrée simple", price: 200000, available: 158, sold: 42 },
      { name: "Table VIP", price: 1500000, available: 5, sold: 0 }
    ],
    tickets: [ // Fictifs: 3 exemples
      { id: 6, user: { name: "Frank Moreau", email: "frank@example.com" }, ticketType: "Entrée simple", price: 200000, purchaseDate: "2025-08-20", isUsed: true },
      { id: 7, user: { name: "Grace Noel", email: "grace@example.com", phone: "+261 33 45 678 90" }, ticketType: "Entrée simple", price: 200000, purchaseDate: "2025-08-21", isUsed: true },
      { id: 8, user: { name: "Hugo Pascal", email: "hugo@example.com" }, ticketType: "Entrée simple", price: 200000, purchaseDate: "2025-08-18", isUsed: false }
    ],
    promotion: undefined
  },
  // ... (ajouter des tickets fictifs similaires pour les autres événements, pour brevité, je n'en mets que pour les 2 premiers ; étendre pour les 10)
  {
    id: 3,
    title: "Techno Revolution",
    date: "10 avril 2025",
    status: "past",
    reservations: 175,
    capacity: 200,
    sales: 36750000,
    coverImage: "https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=400&h=160&fit=crop",
    description: "La soirée techno qui a révolutionné la scène locale avec des artistes internationaux et une ambiance électrique.",
    location: "Club entier",
    time: "22:00 - 06:00",
    artists: [
      { name: "Carl Johnson", image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face" },
      { name: "Techno Sisters", image: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=40&h=40&fit=crop&crop=face" },
      { name: "Max Power", image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop&crop=face" }
    ],
    ticketTypes: [
      { name: "Regular", price: 200000, available: 0, sold: 150 },
      { name: "Premium", price: 350000, available: 0, sold: 25 }
    ],
    tickets: [ // Fictifs: 4 exemples
      { id: 9, user: { name: "Iris Lambert", email: "iris@example.com" }, ticketType: "Regular", price: 200000, purchaseDate: "2025-04-05", isUsed: true },
      { id: 10, user: { name: "Jules Moreau", email: "jules@example.com", phone: "+261 34 56 789 01" }, ticketType: "Premium", price: 350000, purchaseDate: "2025-04-08", isUsed: true },
      { id: 11, user: { name: "Katia Olivier", email: "katia@example.com" }, ticketType: "Regular", price: 200000, purchaseDate: "2025-04-09", isUsed: true },
      { id: 12, user: { name: "Louis Perrin", email: "louis@example.com" }, ticketType: "Regular", price: 200000, purchaseDate: "2025-04-02", isUsed: false }
    ],
    promotion: undefined
  },
  // Continuer pour id 4 à 10 avec des tickets fictifs similaires (ex: 3-5 par événement, varier isUsed, dates récentes/passées)
  {
    id: 4,
    title: "Hip Hop Nights",
    date: "20 décembre 2025",
    status: "upcoming",
    reservations: 120,
    capacity: 250,
    sales: 18000000,
    coverImage: "https://images.unsplash.com/photo-1549576490-b0b4831e7f1f?w=400&h=160&fit=crop",
    description: "Soirée hip hop explosive avec battles et performances live pour une vibe urbaine intense.",
    location: "Zone VIP",
    time: "20:00 - 03:00",
    artists: [
      { name: "MC Blaze", image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face" },
      { name: "Rap Queen", image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&crop=face" }
    ],
    ticketTypes: [
      { name: "General", price: 150000, available: 50, sold: 120 },
      { name: "Backstage", price: 500000, available: 10, sold: 5 }
    ],
    tickets: [
      { id: 13, user: { name: "Marie Quentin", email: "marie@example.com" }, ticketType: "General", price: 150000, purchaseDate: "2025-11-25", isUsed: false },
      { id: 14, user: { name: "Nicolas Remy", email: "nicolas@example.com", phone: "+261 32 12 345 67" }, ticketType: "Backstage", price: 500000, purchaseDate: "2025-12-01", isUsed: false },
      { id: 15, user: { name: "Olivia Sartre", email: "olivia@example.com" }, ticketType: "General", price: 150000, purchaseDate: "2025-11-20", isUsed: false }
    ],
    promotion: {
      title: "Early Bird Hip Hop",
      description: "20% off pour les réservations avant le 1er décembre",
      start: "2025-11-10",
      end: "2025-12-01",
      discount: 20,
      code: "HIPHOP20",
      channels: ['app', 'email', 'social']
    }
  },
  // ... (répéter le pattern pour id 5-10 avec 3-5 tickets fictifs chacun, varier les données)
];

// Mapping pour locations (inchangé)
const locationMap: Record<string, string> = {
  main_room: 'Salle principale',
  terrace: 'Terrasse principale',
  vip_area: 'Zone VIP',
  all: 'Club entier',
};

// Fonction pour formatter les montants en Ariary (inchangé)
const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('fr-MG', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount) + ' Ar';
};

// Composant pour afficher un événement avec des actions (ajout img pour cover)
const EventCard: React.FC<{ event: Event, onManage: (event: Event) => void, onViewSummary: (event: Event) => void }> = ({
  event,
  onManage,
  onViewSummary
}) => {
  const statusColors: Record<string, string> = {
    upcoming: "bg-green-600 text-white",
    planning: "bg-blue-600 text-white",
    past: "border text-muted-foreground",
    cancelled: "bg-red-600 text-white"
  };
  const statusLabels: Record<string, string> = {
    upcoming: "À venir",
    planning: "En planification",
    past: "Passé",
    cancelled: "Annulé"
  };
  return (
    <div className="bg-card rounded-lg overflow-hidden border border-border shadow-sm hover:shadow-md transition-shadow duration-200">
      <img src={event.coverImage} alt={event.title} className="w-full h-40 object-cover" />
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h3 className="font-bold text-lg">{event.title}</h3>
            <p className="text-sm text-muted-foreground">{event.date}</p>
          </div>
          <span className={`px-2 py-1 text-xs font-medium rounded-full ${statusColors[event.status]}`}>
            {statusLabels[event.status]}
          </span>
        </div>
        <div className="mt-4 space-y-2">
          <div className="flex justify-between">
            <span className="text-sm text-muted-foreground">Réservations</span>
            <span className="text-sm font-medium">{event.reservations} / {event.capacity}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm text-muted-foreground">
              {event.status === 'past' ? 'Revenus totaux' : 'Vente de tickets'}
            </span>
            <span className="text-sm font-medium">{formatCurrency(event.sales)}</span>
          </div>
        </div>
        {(event.status === 'upcoming' || event.status === 'planning') ? (
          <Button
            className="w-full mt-4"
            onClick={() => onManage(event)}
          >
            Gérer l'événement
          </Button>
        ) : (
          <Button
            variant="outline"
            className="w-full mt-4"
            onClick={() => onViewSummary(event)}
          >
            Voir le récapitulatif
          </Button>
        )}
      </div>
    </div>
  );
};

const ClubEventsPage: React.FC = () => {
  const { toast } = useToast();
  const [ , navigate] = useLocation(); // Retiré location inutilisé
  const [events, setEvents] = useState<Event[]>(initialEvents); // Stateful
  const [activeTab, setActiveTab] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [isManageModalOpen, setIsManageModalOpen] = useState(false);
  const [isSummaryModalOpen, setIsSummaryModalOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isTicketsModalOpen, setIsTicketsModalOpen] = useState(false); // Nouveau: pour modal tickets détaillé
  const [newEvent, setNewEvent] = useState({
    title: '',
    date: '',
    location: '',
    capacity: '',
    description: ''
  });
  const [editedEvent, setEditedEvent] = useState<Event | null>(null); // Pour édition contrôlée
  const [newArtist, setNewArtist] = useState(''); // Pour ajouter artiste
  const [newTicket, setNewTicket] = useState({ name: '', price: '', available: '', sold: '' }); // Pour ajouter ticket
  const [channels, setChannels] = useState<string[]>([]); // Pour promo channels
  const [selectedTickets, setSelectedTickets] = useState<Ticket[]>([]); // Nouveau: tickets sélectionnés pour modal

  const handleManageEvent = (event: Event) => {
    setSelectedEvent(event);
    setEditedEvent({ ...event, artists: [...event.artists], ticketTypes: [...event.ticketTypes], tickets: [...event.tickets] }); // Copie profonde
    setChannels(event.promotion?.channels || []); // Init channels
    setSelectedTickets(event.tickets); // Init tickets pour modal
    setIsManageModalOpen(true);
  };

  const handleViewSummary = (event: Event) => {
    setSelectedEvent(event);
    setIsSummaryModalOpen(true);
  };

  const handleOpenTicketsModal = () => {
    if (!selectedEvent) return;
    setSelectedTickets(selectedEvent.tickets);
    setIsTicketsModalOpen(true);
  };

  // Nouveau: handlers pour gestion tickets individuels (fictifs pour maquette)
  const handleMarkAsUsed = (ticketId: number) => {
    setSelectedTickets(prev => prev.map(t => t.id === ticketId ? { ...t, isUsed: true } : t));
    // Mise à jour dans events
    if (editedEvent) {
      setEditedEvent(prev => prev ? { ...prev, tickets: prev.tickets.map(t => t.id === ticketId ? { ...t, isUsed: true } : t) } : null);
    }
    toast({ title: "Ticket marqué comme utilisé", description: "Le ticket a été validé avec succès" });
  };

  const handleRefundTicket = (ticketId: number) => {
    if (window.confirm("Confirmer le remboursement de ce ticket ?")) {
      setSelectedTickets(prev => prev.filter(t => t.id !== ticketId));
      if (editedEvent) {
        setEditedEvent(prev => prev ? { ...prev, tickets: prev.tickets.filter(t => t.id !== ticketId) } : null);
      }
      toast({ title: "Ticket remboursé", description: "Le remboursement a été traité" });
    }
  };

  const handleExportTickets = () => {
    toast({ title: "Export", description: "Liste des tickets exportée en CSV" });
  };

  const handleCreateEvent = () => {
    if (!newEvent.title || !newEvent.date || !newEvent.capacity || parseInt(newEvent.capacity) <= 0) {
      toast({ title: "Erreur", description: "Remplissez les champs obligatoires (titre, date, capacité valide)", variant: "destructive" });
      return;
    }
    const newId = Math.max(...events.map(e => e.id), 0) + 1;
    const createdEvent: Event = {
      id: newId,
      title: newEvent.title,
      date: newEvent.date,
      status: 'planning' as const,
      reservations: 0,
      capacity: parseInt(newEvent.capacity),
      sales: 0,
      coverImage: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=160&fit=crop", // Image par défaut
      description: newEvent.description,
      location: locationMap[newEvent.location as keyof typeof locationMap] || newEvent.location,
      time: '21:00 - 04:00',
      artists: [], // Commence vide, ajouter via édition
      ticketTypes: [],
      tickets: [], // Commence vide
      promotion: undefined
    };
    setEvents([...events, createdEvent]);
    setNewEvent({ title: '', date: '', location: '', capacity: '', description: '' });
    setIsCreateModalOpen(false);
    toast({ title: "Événement créé", description: "Votre nouvel événement a été créé avec succès" });
  };

  const handleUpdateEventDetails = () => {
    if (!editedEvent) return;
    setEvents(events.map(e => e.id === editedEvent.id ? editedEvent : e));
    setIsManageModalOpen(false);
    setEditedEvent(null);
    toast({ title: "Événement mis à jour", description: "Les détails de l'événement ont été mis à jour avec succès" });
  };

  const handleDeleteEvent = () => {
    if (!selectedEvent) return;
    if (window.confirm(`Confirmer la suppression de "${selectedEvent.title}" ?`)) {
      setEvents(events.filter(e => e.id !== selectedEvent.id));
      setIsManageModalOpen(false);
      setEditedEvent(null);
      toast({ title: "Événement supprimé", description: "L'événement a été supprimé avec succès", variant: "destructive" });
    }
  };

  const addArtist = () => {
    if (!newArtist.trim() || !editedEvent) return;
    const artistImage = "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=40&h=40&fit=crop&crop=face"; // Image par défaut
    setEditedEvent({ ...editedEvent, artists: [...editedEvent.artists, { name: newArtist.trim(), image: artistImage }] });
    setNewArtist('');
    toast({ title: "Artiste ajouté", description: `Artiste "${newArtist}" ajouté à l'événement` });
  };

  const removeArtist = (artistName: string) => {
    if (!editedEvent) return;
    setEditedEvent({ ...editedEvent, artists: editedEvent.artists.filter(a => a.name !== artistName) });
    toast({ title: "Artiste supprimé", description: `Artiste "${artistName}" supprimé` });
  };

  const addTicket = () => {
    if (!newTicket.name || !newTicket.price || !editedEvent) return;
    const priceNum = parseInt(newTicket.price);
    const availNum = parseInt(newTicket.available) || 0;
    const soldNum = parseInt(newTicket.sold) || 0;
    if (priceNum <= 0) {
      toast({ variant: "destructive", title: "Erreur", description: "Prix doit être positif" });
      return;
    }
    const newTicketType = {
      name: newTicket.name,
      price: priceNum,
      available: availNum,
      sold: soldNum
    };
    setEditedEvent({ ...editedEvent, ticketTypes: [...editedEvent.ticketTypes, newTicketType] });
    setNewTicket({ name: '', price: '', available: '', sold: '' });
    toast({ title: "Ticket ajouté", description: `Type de ticket "${newTicket.name}" ajouté` });
  };

  const updateTicket = (index: number, field: keyof typeof newTicket, value: string | number) => {
    if (!editedEvent) return;
    const updatedTickets = [...editedEvent.ticketTypes];
    updatedTickets[index] = { ...updatedTickets[index], [field]: typeof value === 'number' ? value : parseInt(value) || 0 };
    setEditedEvent({ ...editedEvent, ticketTypes: updatedTickets });
  };

  const removeTicket = (index: number) => {
    if (!editedEvent) return;
    if (window.confirm('Confirmer la suppression de ce type de ticket ?')) {
      const updatedTickets = editedEvent.ticketTypes.filter((_, i) => i !== index);
      setEditedEvent({ ...editedEvent, ticketTypes: updatedTickets });
      toast({ title: "Ticket supprimé", description: "Type de ticket supprimé" });
    }
  };

  const updatePromotion = () => {
    if (!editedEvent) return;
    const promo = editedEvent.promotion || {
      title: '',
      description: '',
      start: '',
      end: '',
      discount: 0,
      code: '',
      channels: channels
    };
    // Ici, on pourrait merger avec les champs du form, mais pour simplicité, assumez que les inputs contrôlent editedEvent.promotion
    setEditedEvent({ ...editedEvent, promotion: { ...promo, channels } });
    toast({ title: "Promotion mise à jour", description: "La promotion a été sauvegardée" });
  };

  const toggleChannel = (channel: string) => {
    setChannels(prev => prev.includes(channel) ? prev.filter(c => c !== channel) : [...prev, channel]);
  };

  const handlePublishPromotion = () => {
    if (!editedEvent) return;
    updatePromotion(); // Sauvegarde
    toast({
      title: "Promotion publiée",
      description: `La promotion pour "${editedEvent.title}" a été publiée avec succès`,
    });
  };

  const filteredEvents = events
    .filter(event =>
      event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.artists.some(a => a.name.toLowerCase().includes(searchTerm.toLowerCase()))
    )
    .filter(event =>
      activeTab === 'all' ||
      (activeTab === 'upcoming' && event.status === 'upcoming') ||
      (activeTab === 'planning' && event.status === 'planning') ||
      (activeTab === 'past' && event.status === 'past') ||
      (activeTab === 'cancelled' && event.status === 'cancelled') // Ajout filtre cancelled
    );

  // Handler pour navigation (stub pour démo)
  const handleNavigate = (path: string) => {
    toast({ title: "Navigation", description: `Redirection vers ${path} (page non implémentée pour démo)` });
    // navigate(path); // Décommentez si routes existent
  };

  return (
    <ResponsiveLayout>
      <div className="p-6 md:p-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold">Événements du club</h1>
            <p className="text-lg text-muted-foreground mt-1">Gérez vos événements passés et à venir</p>
          </div>
          <Button
            onClick={() => setIsCreateModalOpen(true)}
            className="mt-4 md:mt-0"
          >
            Créer un événement
          </Button>
        </div>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <Tabs
            defaultValue="all"
            className="w-full sm:w-auto"
            value={activeTab}
            onValueChange={setActiveTab}
          >
            <TabsList>
              <TabsTrigger value="all">Tous</TabsTrigger>
              <TabsTrigger value="upcoming">À venir</TabsTrigger>
              <TabsTrigger value="planning">Planification</TabsTrigger>
              <TabsTrigger value="past">Passés</TabsTrigger>
              <TabsTrigger value="cancelled">Annulés</TabsTrigger> {/* Ajout onglet pour filtre */}
            </TabsList>
          </Tabs>
          <div className="w-full sm:w-64">
            <Input
              placeholder="Rechercher un événement, artiste..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full"
            />
          </div>
        </div>
        {filteredEvents.length === 0 ? (
          <div className="text-center py-16 bg-muted/20 rounded-lg border border-dashed border-muted">
            <AlertCircle className="h-10 w-10 mx-auto text-muted-foreground" />
            <h3 className="mt-4 text-lg font-medium">Aucun événement trouvé</h3>
            <p className="mt-2 text-muted-foreground">
              Aucun événement ne correspond à vos critères de recherche
            </p>
            <Button
              variant="outline"
              className="mt-4"
              onClick={() => {
                setSearchTerm('');
                setActiveTab('all');
              }}
            >
              Effacer les filtres
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEvents.map(event => (
              <EventCard
                key={event.id}
                event={event}
                onManage={handleManageEvent}
                onViewSummary={handleViewSummary}
              />
            ))}
          </div>
        )}
        {/* Statistiques rapides (utilise events state) */}
        <div className="mt-12">
          <h2 className="text-xl font-semibold mb-4">Statistiques rapides</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total d'événements</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{events.length}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {events.filter(e => e.status === 'upcoming').length} à venir
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Revenus totaux</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(events.reduce((acc, event) => acc + event.sales, 0))}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  Tous événements confondus
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Taux de remplissage moyen</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {events.reduce((acc, event) => acc + event.capacity, 0) > 0
                    ? Math.round(
                        (events.reduce((acc, event) => acc + event.reservations, 0) /
                          events.reduce((acc, event) => acc + event.capacity, 0)) * 100
                      )
                    : 0}%
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Basé sur tous les événements
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Artistes invités</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {new Set(events.flatMap(event => event.artists.map(a => a.name))).size}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Artistes uniques programmés
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      {/* Modale de gestion d'événement (contrôlée, ajustée pour artistes avec img) */}
      {selectedEvent && editedEvent && (
        <Dialog open={isManageModalOpen} onOpenChange={setIsManageModalOpen}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Gérer l'événement: {editedEvent.title}</DialogTitle>
              <DialogDescription>
                Modifiez les détails ou gérez les tickets de cet événement
              </DialogDescription>
            </DialogHeader>
            
            <Tabs defaultValue="details">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="details">Détails</TabsTrigger>
                <TabsTrigger value="tickets">Tickets</TabsTrigger>
                <TabsTrigger value="artists">Artistes</TabsTrigger>
                <TabsTrigger value="promo">Promotion</TabsTrigger>
              </TabsList>
              
              <TabsContent value="details" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="event-title">Titre de l'événement</Label>
                    <Input 
                      id="event-title" 
                      value={editedEvent.title} 
                      onChange={(e) => setEditedEvent(prev => prev ? { ...prev, title: e.target.value } : null)} 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="event-date">Date</Label>
                    <Input 
                      id="event-date" 
                      type="date"
                      value={editedEvent.date} 
                      onChange={(e) => setEditedEvent(prev => prev ? { ...prev, date: e.target.value } : null)} 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="event-time">Horaires</Label>
                    <Input 
                      id="event-time" 
                      value={editedEvent.time} 
                      onChange={(e) => setEditedEvent(prev => prev ? { ...prev, time: e.target.value } : null)} 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="event-location">Lieu</Label>
                    <Select 
                      value={Object.keys(locationMap).find(key => locationMap[key] === editedEvent.location) || ''} 
                      onValueChange={(value) => setEditedEvent(prev => prev ? { ...prev, location: locationMap[value as keyof typeof locationMap] } : null)}
                    >
                      <SelectTrigger id="event-location">
                        <SelectValue placeholder="Sélectionner un lieu" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="main_room">Salle principale</SelectItem>
                        <SelectItem value="terrace">Terrasse principale</SelectItem>
                        <SelectItem value="vip_area">Zone VIP</SelectItem>
                        <SelectItem value="all">Club entier</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="event-description">Description</Label>
                    <Textarea
                      id="event-description"
                      value={editedEvent.description}
                      onChange={(e) => setEditedEvent(prev => prev ? { ...prev, description: e.target.value } : null)}
                      rows={4}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="event-capacity">Capacité</Label>
                    <Input 
                      id="event-capacity" 
                      type="number" 
                      value={editedEvent.capacity} 
                      onChange={(e) => setEditedEvent(prev => prev ? { ...prev, capacity: parseInt(e.target.value) || 0 } : null)} 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="event-status">Statut</Label>
                    <Select 
                      value={editedEvent.status} 
                      onValueChange={(value) => setEditedEvent(prev => prev ? { ...prev, status: value as Event['status'] } : null)}
                    >
                      <SelectTrigger id="event-status">
                        <SelectValue placeholder="Sélectionner un statut" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="planning">En planification</SelectItem>
                        <SelectItem value="upcoming">À venir</SelectItem>
                        <SelectItem value="past">Passé</SelectItem>
                        <SelectItem value="cancelled">Annulé</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <DialogFooter>
                  <Button variant="outline" onClick={() => { setIsManageModalOpen(false); setEditedEvent(null); }}>Annuler</Button>
                  <Button onClick={handleUpdateEventDetails}>Enregistrer les modifications</Button>
                  <Button variant="destructive" onClick={handleDeleteEvent}>
                    <Trash2 className="h-4 w-4 mr-2" /> Supprimer l'événement
                  </Button>
                </DialogFooter>
              </TabsContent>
              
              <TabsContent value="tickets" className="space-y-4">
                {/* Onglet tickets: types + bouton pour modal détaillé */}
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 font-medium">Type de ticket</th>
                        <th className="text-left py-3 font-medium">Prix</th>
                        <th className="text-left py-3 font-medium">Vendus</th>
                        <th className="text-left py-3 font-medium">Disponibles</th>
                        <th className="text-left py-3 font-medium">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {editedEvent.ticketTypes.map((ticket, index) => (
                        <tr key={index} className="border-b hover:bg-muted/50">
                          <td className="py-3">
                            <Input 
                              value={ticket.name} 
                              onChange={(e) => updateTicket(index, 'name', e.target.value)} 
                              className="w-32" 
                            />
                          </td>
                          <td className="py-3">
                            <Input 
                              type="number" 
                              value={ticket.price} 
                              onChange={(e) => updateTicket(index, 'price', e.target.value)} 
                              className="w-24" 
                            />
                          </td>
                          <td className="py-3">
                            <Input 
                              type="number" 
                              value={ticket.sold} 
                              onChange={(e) => updateTicket(index, 'sold', e.target.value)} 
                              className="w-20" 
                            />
                          </td>
                          <td className="py-3">
                            <Input 
                              type="number" 
                              value={ticket.available} 
                              onChange={(e) => updateTicket(index, 'available', e.target.value)} 
                              className="w-24" 
                            />
                          </td>
                          <td className="py-3">
                            <Button variant="outline" size="sm" onClick={() => removeTicket(index)}>
                              Supprimer
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                
                {/* Form pour ajouter ticket */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 border rounded-lg bg-muted/20">
                  <Input 
                    placeholder="Nom" 
                    value={newTicket.name} 
                    onChange={(e) => setNewTicket({...newTicket, name: e.target.value})} 
                  />
                  <Input 
                    type="number" 
                    placeholder="Prix" 
                    value={newTicket.price} 
                    onChange={(e) => setNewTicket({...newTicket, price: e.target.value})} 
                  />
                  <Input 
                    type="number" 
                    placeholder="Disponibles" 
                    value={newTicket.available} 
                    onChange={(e) => setNewTicket({...newTicket, available: e.target.value})} 
                  />
                  <Input 
                    type="number" 
                    placeholder="Vendus" 
                    value={newTicket.sold} 
                    onChange={(e) => setNewTicket({...newTicket, sold: e.target.value})} 
                  />
                  <Button onClick={addTicket} className="md:col-span-4">Ajouter ticket</Button>
                </div>

                {/* Nouveau bouton pour ouvrir modal tickets détaillés */}
                <div className="flex justify-end">
                  <Button onClick={handleOpenTicketsModal} className="flex items-center gap-2">
                    <Ticket className="h-4 w-4" />
                    Gérer les tickets individuels ({editedEvent.tickets.length} vendus)
                  </Button>
                </div>
                
                <DialogFooter className="mt-4">
                  <Button variant="outline" onClick={() => { setIsManageModalOpen(false); setEditedEvent(null); }}>Fermer</Button>
                  <Button onClick={handleUpdateEventDetails}>Enregistrer les modifications</Button>
                </DialogFooter>
              </TabsContent>
              
              <TabsContent value="artists" className="space-y-4">
                <div className="space-y-4">
                  {editedEvent.artists.map((artist, index) => (
                    <div key={index} className="flex items-center justify-between py-2 border-b">
                      <div className="flex items-center space-x-3">
                        <img src={artist.image} alt={artist.name} className="w-10 h-10 rounded-full object-cover" />
                        <div>
                          <p className="font-medium">{artist.name}</p>
                          <p className="text-sm text-muted-foreground">Performance confirmée</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" onClick={() => removeArtist(artist.name)}>
                        Supprimer
                      </Button>
                    </div>
                  ))}
                </div>
                
                {/* Form pour ajouter artiste */}
                <div className="flex space-x-2">
                  <Input 
                    placeholder="Nom de l'artiste" 
                    value={newArtist} 
                    onChange={(e) => setNewArtist(e.target.value)} 
                    className="flex-1" 
                  />
                  <Button onClick={addArtist}><Plus className="h-4 w-4 mr-1" /> Ajouter</Button>
                </div>
                
                <div className="flex space-x-2 mt-4">
                  <Button variant="outline" className="flex-1" onClick={() => handleNavigate("/club/find-artists")}>
                    Trouver des artistes
                  </Button>
                  <Button variant="outline" className="flex-1" onClick={() => handleNavigate("/club/invitations")}>
                    Invitations en cours
                  </Button>
                </div>
                
                <DialogFooter className="mt-4">
                  <Button variant="outline" onClick={() => { setIsManageModalOpen(false); setEditedEvent(null); }}>Fermer</Button>
                  <Button onClick={handleUpdateEventDetails}>Enregistrer les modifications</Button>
                </DialogFooter>
              </TabsContent>
              
              <TabsContent value="promo" className="space-y-4">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="promo-title">Titre de la promotion</Label>
                    <Input 
                      id="promo-title" 
                      placeholder="Ex: Early Bird Special - 20% de réduction" 
                      value={editedEvent.promotion?.title || ''} 
                      onChange={(e) => setEditedEvent(prev => prev ? { ...prev, promotion: { ...(prev.promotion || {}), title: e.target.value } } : null)} 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="promo-desc">Description</Label>
                    <Textarea
                      id="promo-desc"
                      rows={3}
                      placeholder="Décrivez cette offre promotionnelle..."
                      value={editedEvent.promotion?.description || ''}
                      onChange={(e) => setEditedEvent(prev => prev ? { ...prev, promotion: { ...(prev.promotion || {}), description: e.target.value } } : null)}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="promo-start">Date de début</Label>
                      <Input 
                        id="promo-start" 
                        type="date" 
                        value={editedEvent.promotion?.start || ''} 
                        onChange={(e) => setEditedEvent(prev => prev ? { ...prev, promotion: { ...(prev.promotion || {}), start: e.target.value } } : null)} 
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="promo-end">Date de fin</Label>
                      <Input 
                        id="promo-end" 
                        type="date" 
                        value={editedEvent.promotion?.end || ''} 
                        onChange={(e) => setEditedEvent(prev => prev ? { ...prev, promotion: { ...(prev.promotion || {}), end: e.target.value } } : null)} 
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="promo-discount">Réduction (%)</Label>
                      <Input 
                        id="promo-discount" 
                        type="number" 
                        min="1" 
                        max="100" 
                        placeholder="20" 
                        value={editedEvent.promotion?.discount || 0} 
                        onChange={(e) => setEditedEvent(prev => prev ? { ...prev, promotion: { ...(prev.promotion || {}), discount: parseInt(e.target.value) || 0 } } : null)} 
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="promo-code">Code promo (optionnel)</Label>
                      <Input 
                        id="promo-code" 
                        placeholder="SUMMER2025" 
                        value={editedEvent.promotion?.code || ''} 
                        onChange={(e) => setEditedEvent(prev => prev ? { ...prev, promotion: { ...(prev.promotion || {}), code: e.target.value } } : null)} 
                      />
                    </div>
                  </div>
                  
                  <div className="border rounded-lg p-4 bg-muted/20">
                    <h4 className="font-medium mb-2">Canaux de distribution</h4>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {['app', 'email', 'sms', 'social', 'push'].map(channel => (
                        <div key={channel} className="flex items-center space-x-2">
                          <input 
                            type="checkbox" 
                            id={`channel-${channel}`} 
                            className="rounded" 
                            checked={channels.includes(channel)} 
                            onChange={() => toggleChannel(channel)} 
                          />
                          <label htmlFor={`channel-${channel}`}>{channel.charAt(0).toUpperCase() + channel.slice(1)}</label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                
                <DialogFooter className="mt-4">
                  <Button variant="outline" onClick={() => { setIsManageModalOpen(false); setEditedEvent(null); }}>Annuler</Button>
                  <Button onClick={handlePublishPromotion}>Publier la promotion</Button>
                </DialogFooter>
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      )}
      {/* Nouveau: Modale pour gérer les tickets individuels (maquette avec données fictives) */}
      <Dialog open={isTicketsModalOpen} onOpenChange={setIsTicketsModalOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Gestion des tickets: {selectedEvent?.title}</DialogTitle>
            <DialogDescription>
              Visualisez et gérez les tickets vendus pour cet événement. {selectedTickets.length} tickets au total.
            </DialogDescription>
          </DialogHeader>
          
          {/* Stats rapides tickets */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Tickets vendus</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{selectedTickets.length}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Utilisés</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{selectedTickets.filter(t => t.isUsed).length}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Revenu</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(selectedTickets.reduce((acc, t) => acc + t.price, 0))}</div>
              </CardContent>
            </Card>
          </div>
          
          {/* Tableau des tickets */}
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID Ticket</TableHead>
                  <TableHead>Utilisateur</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Prix</TableHead>
                  <TableHead>Date d'achat</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {selectedTickets.map((ticket) => (
                  <TableRow key={ticket.id} className="hover:bg-muted/50">
                    <TableCell className="font-medium">{ticket.id}</TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium">{ticket.user.name}</p>
                        <p className="text-sm text-muted-foreground">{ticket.user.email}</p>
                        {ticket.user.phone && <p className="text-xs text-muted-foreground">{ticket.user.phone}</p>}
                      </div>
                    </TableCell>
                    <TableCell><Badge variant={ticket.ticketType === 'VIP' ? 'secondary' : 'default'}>{ticket.ticketType}</Badge></TableCell>
                    <TableCell>{formatCurrency(ticket.price)}</TableCell>
                    <TableCell>{ticket.purchaseDate}</TableCell>
                    <TableCell>
                      <Badge variant={ticket.isUsed ? 'default' : 'secondary'}>
                        {ticket.isUsed ? <CheckCircle className="h-3 w-3 mr-1" /> : <XCircle className="h-3 w-3 mr-1" />}
                        {ticket.isUsed ? 'Utilisé' : 'Non utilisé'}
                      </Badge>
                    </TableCell>
                    <TableCell className="space-x-2">
                      {!ticket.isUsed && (
                        <Button size="sm" variant="outline" onClick={() => handleMarkAsUsed(ticket.id)}>
                          Valider
                        </Button>
                      )}
                      <Button size="sm" variant="destructive" onClick={() => handleRefundTicket(ticket.id)}>
                        Rembourser
                      </Button>
                      <Button size="sm" variant="ghost">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={handleExportTickets}>
              <Download className="h-4 w-4 mr-2" /> Exporter CSV
            </Button>
            <Button variant="outline" onClick={() => setIsTicketsModalOpen(false)}>Fermer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {/* Modale de récapitulatif d'événement (ajout affichage artistes avec img) */}
      {selectedEvent && (
        <Dialog open={isSummaryModalOpen} onOpenChange={setIsSummaryModalOpen}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Récapitulatif: {selectedEvent.title}</DialogTitle>
              <DialogDescription>
                Vue d'ensemble de l'événement et de ses performances
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Taux de remplissage</CardDescription>
                  <CardTitle className="text-2xl">
                    {Math.round((selectedEvent.reservations / selectedEvent.capacity) * 100)}%
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    {selectedEvent.reservations} participants sur {selectedEvent.capacity} places
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Revenu total</CardDescription>
                  <CardTitle className="text-2xl">
                    {formatCurrency(selectedEvent.sales)}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    {selectedEvent.ticketTypes.reduce((acc, ticket) => acc + ticket.sold, 0)} tickets vendus
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Ventes additionnelles</CardDescription>
                  <CardTitle className="text-2xl">
                    {formatCurrency(selectedEvent.sales * 0.35)}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Boissons, nourriture et autres
                  </p>
                </CardContent>
              </Card>
            </div>
            
            {selectedEvent.promotion && (
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Promotion active</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="font-medium">{selectedEvent.promotion.title}</p>
                  <p className="text-sm text-muted-foreground mt-1">Réduction: {selectedEvent.promotion.discount}% - Code: {selectedEvent.promotion.code || 'N/A'}</p>
                </CardContent>
              </Card>
            )}
            
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-2">Informations de l'événement</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center space-x-3">
                    <Calendar className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Date</p>
                      <p className="text-sm text-muted-foreground">{selectedEvent.date}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <Clock className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Horaires</p>
                      <p className="text-sm text-muted-foreground">{selectedEvent.time}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <MapPin className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Lieu</p>
                      <p className="text-sm text-muted-foreground">{selectedEvent.location}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <Music className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Artistes</p>
                      <p className="text-sm text-muted-foreground flex flex-wrap gap-2">
                        {selectedEvent.artists.map((artist, idx) => (
                          <span key={idx} className="flex items-center gap-1 text-xs bg-muted px-2 py-1 rounded">
                            <img src={artist.image} alt={artist.name} className="w-4 h-4 rounded-full object-cover" />
                            {artist.name}
                          </span>
                        ))}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-medium mb-2">Analyse des ventes de tickets</h3>
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 font-medium">Type de ticket</th>
                      <th className="text-left py-2 font-medium">Prix</th>
                      <th className="text-left py-2 font-medium">Vendus</th>
                      <th className="text-left py-2 font-medium">Revenu</th>
                      <th className="text-left py-2 font-medium">% du total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedEvent.ticketTypes.map((ticket, index) => (
                      <tr key={index} className="border-b">
                        <td className="py-2">{ticket.name}</td>
                        <td className="py-2">{formatCurrency(ticket.price)}</td>
                        <td className="py-2">{ticket.sold}</td>
                        <td className="py-2">{formatCurrency(ticket.price * ticket.sold)}</td>
                        <td className="py-2">
                          {selectedEvent.sales > 0 ? Math.round((ticket.price * ticket.sold / selectedEvent.sales) * 100) : 0}%
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Répartition démographique</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">18-24 ans</span>
                      <span className="text-sm font-medium">35%</span>
                    </div>
                    <div className="w-full bg-secondary h-2 rounded-full overflow-hidden">
                      <div className="bg-primary h-full rounded-full" style={{ width: '35%' }}></div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm">25-34 ans</span>
                      <span className="text-sm font-medium">45%</span>
                    </div>
                    <div className="w-full bg-secondary h-2 rounded-full overflow-hidden">
                      <div className="bg-primary h-full rounded-full" style={{ width: '45%' }}></div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm">35-44 ans</span>
                      <span className="text-sm font-medium">15%</span>
                    </div>
                    <div className="w-full bg-secondary h-2 rounded-full overflow-hidden">
                      <div className="bg-primary h-full rounded-full" style={{ width: '15%' }}></div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm">45+ ans</span>
                      <span className="text-sm font-medium">5%</span>
                    </div>
                    <div className="w-full bg-secondary h-2 rounded-full overflow-hidden">
                      <div className="bg-primary h-full rounded-full" style={{ width: '5%' }}></div>
                    </div>
                  </div>
                  <div className="mt-4 flex justify-between">
                    <div className="text-center">
                      <p className="text-xl font-medium">60%</p>
                      <p className="text-sm text-muted-foreground">Hommes</p>
                    </div>
                    <div className="text-center">
                      <p className="text-xl font-medium">40%</p>
                      <p className="text-sm text-muted-foreground">Femmes</p>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-2">Avis et engagement</h3>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-1">
                      {[1, 2, 3, 4, 5].map((_, i) => (
                        <Award key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      ))}
                      <span className="ml-2 font-medium">4.8/5</span>
                      <span className="text-sm text-muted-foreground ml-2">(42 avis)</span>
                    </div>
                    
                    <div className="space-y-3 mt-3">
                      <div className="p-3 bg-muted rounded-lg">
                        <p className="text-sm italic">"Excellente soirée, l'ambiance était électrique et l'organisation parfaite."</p>
                        <p className="text-xs text-muted-foreground mt-1">Marie L. - Utilisateur premium</p>
                      </div>
                      
                      <div className="p-3 bg-muted rounded-lg">
                        <p className="text-sm italic">"Les DJ étaient incroyables, mais un peu trop de monde à mon goût."</p>
                        <p className="text-xs text-muted-foreground mt-1">Thomas M. - Première visite</p>
                      </div>
                    </div>
                    
                    <div className="mt-3">
                      <h4 className="text-sm font-medium mb-2">Partages sur les réseaux sociaux</h4>
                      <div className="flex space-x-3">
                        <div className="flex items-center space-x-1">
                          <div className="h-6 w-6 rounded-full bg-blue-600 flex items-center justify-center">
                            <span className="text-white text-xs font-bold">f</span>
                          </div>
                          <span className="text-sm">124</span>
                        </div>
                        
                        <div className="flex items-center space-x-1">
                          <div className="h-6 w-6 rounded-full bg-sky-500 flex items-center justify-center">
                            <span className="text-white text-xs font-bold">t</span>
                          </div>
                          <span className="text-sm">87</span>
                        </div>
                        
                        <div className="flex items-center space-x-1">
                          <div className="h-6 w-6 rounded-full bg-pink-600 flex items-center justify-center">
                            <span className="text-white text-xs font-bold">i</span>
                          </div>
                          <span className="text-sm">203</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsSummaryModalOpen(false)}>Fermer</Button>
              <Button onClick={() => {
                toast({
                  title: "Rapport exporté",
                  description: "Le rapport a été exporté au format PDF",
                });
              }}>Exporter le rapport</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      {/* Modale de création d'événement (légèrement ajustée pour Select contrôlé) */}
      <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Créer un nouvel événement</DialogTitle>
            <DialogDescription>
              Remplissez les informations pour créer un nouvel événement pour votre club
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="title">Titre de l'événement</Label>
              <Input
                id="title"
                placeholder="Soirée Summer Vibes 2025"
                value={newEvent.title}
                onChange={(e) => setNewEvent({...newEvent, title: e.target.value})}
              />
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={newEvent.date}
                  onChange={(e) => setNewEvent({...newEvent, date: e.target.value})}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="capacity">Capacité</Label>
                <Input
                  id="capacity"
                  type="number"
                  placeholder="200"
                  value={newEvent.capacity}
                  onChange={(e) => setNewEvent({...newEvent, capacity: e.target.value})}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="location">Lieu dans le club</Label>
              <Select value={newEvent.location} onValueChange={(value) => setNewEvent({...newEvent, location: value})}>
                <SelectTrigger id="location">
                  <SelectValue placeholder="Sélectionner un lieu" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="main_room">Salle principale</SelectItem>
                  <SelectItem value="terrace">Terrasse principale</SelectItem>
                  <SelectItem value="vip_area">Zone VIP</SelectItem>
                  <SelectItem value="all">Club entier</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                rows={3}
                placeholder="Décrivez votre événement en quelques phrases..."
                value={newEvent.description}
                onChange={(e) => setNewEvent({...newEvent, description: e.target.value})}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateModalOpen(false)}>Annuler</Button>
            <Button onClick={handleCreateEvent}>Créer l'événement</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </ResponsiveLayout>
  );
};

export default ClubEventsPage;